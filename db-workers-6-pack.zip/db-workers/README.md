# DB Workers Pack (6 folders)

This zip contains 6 standalone Cloudflare Worker backends, each wired to a different production database.

Folders:
- 01-d1 (Cloudflare D1)
- 02-neon-postgres (Neon Postgres)
- 03-planetscale-mysql (PlanetScale MySQL)
- 04-turso-libsql (Turso/libSQL)
- 05-mongodb-atlas (MongoDB Atlas Data API)
- 06-supabase-postgres (Supabase Postgres via PostgREST)

All workers expose the same minimal API:
- GET /health
- GET /users
- POST /users { "email": "test@example.com" }

## Deploy (per folder)
1. cd into the folder
2. Install deps if needed (npm i)
3. Configure env vars/secrets
4. wrangler deploy

## Notes
- D1 runs only on Cloudflare (binding name: DB).
- MongoDB worker uses Atlas Data API (HTTP) and does not run SQL.
- Supabase worker uses PostgREST via service role key.
