# 03-planetscale-mysql

## Env (use wrangler secret put for password)
PLANETSCALE_HOST=...
PLANETSCALE_USERNAME=...
PLANETSCALE_PASSWORD=...

## Install
npm i

## Deploy
wrangler deploy
