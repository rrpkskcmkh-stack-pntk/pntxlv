import { Client } from "@planetscale/database";

export default {
  async fetch(
    req: Request,
    env: { PLANETSCALE_HOST: string; PLANETSCALE_USERNAME: string; PLANETSCALE_PASSWORD: string }
  ) {
    const client = new Client({
      host: env.PLANETSCALE_HOST,
      username: env.PLANETSCALE_USERNAME,
      password: env.PLANETSCALE_PASSWORD,
    });

    const url = new URL(req.url);

    if (url.pathname === "/health") {
      const r = await client.execute("SELECT 1 AS ok");
      return Response.json({ db: "planetscale-mysql", ok: (r.rows?.[0] as any)?.ok === 1 });
    }

    if (url.pathname === "/users" && req.method === "GET") {
      const r = await client.execute("SELECT id, email, created_at FROM users ORDER BY created_at DESC LIMIT 50");
      return Response.json({ users: r.rows ?? [] });
    }

    if (url.pathname === "/users" && req.method === "POST") {
      const body = await req.json().catch(() => ({} as any));
      const email = String(body.email || "");
      if (!email) return Response.json({ error: "email_required" }, { status: 400 });

      const id = crypto.randomUUID();
      await client.execute("INSERT INTO users (id, email, created_at) VALUES (?, ?, NOW())", [id, email]);
      return Response.json({ ok: true, id });
    }

    return new Response("Not Found", { status: 404 });
  },
};
