export default {
  async fetch(req: Request, env: { DB: D1Database }) {
    const url = new URL(req.url);

    if (url.pathname === "/health") {
      const r = await env.DB.prepare("SELECT 1 AS ok").first<{ ok: number }>();
      return Response.json({ db: "d1", ok: r?.ok === 1 });
    }

    if (url.pathname === "/users" && req.method === "GET") {
      const r = await env.DB
        .prepare("SELECT id, email, created_at FROM users ORDER BY created_at DESC LIMIT 50")
        .all();
      return Response.json({ users: r.results ?? [] });
    }

    if (url.pathname === "/users" && req.method === "POST") {
      const body = await req.json().catch(() => ({} as any));
      const email = String(body.email || "");
      if (!email) return Response.json({ error: "email_required" }, { status: 400 });

      const id = crypto.randomUUID();
      await env.DB
        .prepare("INSERT INTO users (id, email, created_at) VALUES (?, ?, datetime('now'))")
        .bind(id, email)
        .run();

      return Response.json({ ok: true, id });
    }

    return new Response("Not Found", { status: 404 });
  },
};
