# 01-d1 (Cloudflare D1)

## Setup
- Create a D1 database: wrangler d1 create <name>
- Put the returned database_id into wrangler.json
- Apply migrations: wrangler d1 migrations apply <database_id>

## Run/Deploy
- wrangler dev
- wrangler deploy
