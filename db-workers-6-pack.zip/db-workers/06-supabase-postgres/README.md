# 06-supabase-postgres (PostgREST)

## Env
SUPABASE_URL=https://xxxx.supabase.co
SUPABASE_SERVICE_ROLE_KEY=...

Deploy:
wrangler deploy
