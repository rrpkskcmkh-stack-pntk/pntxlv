async function sbFetch(env: any, path: string, init?: RequestInit) {
  const r = await fetch(`${env.SUPABASE_URL}${path}`, {
    ...init,
    headers: {
      "content-type": "application/json",
      "apikey": env.SUPABASE_SERVICE_ROLE_KEY,
      "authorization": `Bearer ${env.SUPABASE_SERVICE_ROLE_KEY}`,
      ...(init?.headers || {}),
    },
  });
  if (!r.ok) throw new Error(`Supabase error: ${r.status}`);
  const text = await r.text();
  return text ? JSON.parse(text) : null;
}

export default {
  async fetch(req: Request, env: any) {
    const url = new URL(req.url);

    if (url.pathname === "/health") {
      await sbFetch(env, "/rest/v1/users?select=id&limit=1");
      return Response.json({ db: "supabase-postgres", ok: true });
    }

    if (url.pathname === "/users" && req.method === "GET") {
      const users = await sbFetch(env, "/rest/v1/users?select=id,email,created_at&order=created_at.desc&limit=50");
      return Response.json({ users: users ?? [] });
    }

    if (url.pathname === "/users" && req.method === "POST") {
      const body = await req.json().catch(() => ({} as any));
      const email = String(body.email || "");
      if (!email) return Response.json({ error: "email_required" }, { status: 400 });

      const id = crypto.randomUUID();
      await sbFetch(env, "/rest/v1/users", {
        method: "POST",
        headers: { "Prefer": "return=minimal" },
        body: JSON.stringify([{ id, email, created_at: new Date().toISOString() }]),
      });
      return Response.json({ ok: true, id });
    }

    return new Response("Not Found", { status: 404 });
  },
};
