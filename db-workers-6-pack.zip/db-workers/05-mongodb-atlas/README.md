# 05-mongodb-atlas (Atlas Data API)

## Env
MONGODB_DATA_API_URL=https://data.mongodb-api.com/app/<app-id>/endpoint/data/v1
MONGODB_DATA_API_KEY=...
MONGODB_DATASOURCE=Cluster0
MONGODB_DB=pentok

## Deploy
wrangler deploy
