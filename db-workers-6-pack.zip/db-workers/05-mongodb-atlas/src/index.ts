async function mongo(env: any, action: string, body: any) {
  const r = await fetch(`${env.MONGODB_DATA_API_URL}/action/${action}`, {
    method: "POST",
    headers: { "content-type": "application/json", "api-key": env.MONGODB_DATA_API_KEY },
    body: JSON.stringify(body),
  });
  if (!r.ok) throw new Error(`Mongo Data API error: ${r.status}`);
  return r.json();
}

export default {
  async fetch(req: Request, env: any) {
    const url = new URL(req.url);
    const dataSource = env.MONGODB_DATASOURCE || "Cluster0";
    const database = env.MONGODB_DB || "pentok";
    const collection = "users";

    if (url.pathname === "/health") {
      await mongo(env, "findOne", { dataSource, database, collection, filter: {} });
      return Response.json({ db: "mongodb-atlas-data-api", ok: true });
    }

    if (url.pathname === "/users" && req.method === "GET") {
      const res = await mongo(env, "find", {
        dataSource, database, collection,
        filter: {},
        limit: 50,
        sort: { created_at: -1 },
        projection: { _id: 1, email: 1, created_at: 1 },
      });
      return Response.json({ users: res.documents ?? [] });
    }

    if (url.pathname === "/users" && req.method === "POST") {
      const body = await req.json().catch(() => ({} as any));
      const email = String(body.email || "");
      if (!email) return Response.json({ error: "email_required" }, { status: 400 });

      const doc = { email, created_at: new Date().toISOString() };
      const res = await mongo(env, "insertOne", { dataSource, database, collection, document: doc });
      return Response.json({ ok: true, id: res.insertedId });
    }

    return new Response("Not Found", { status: 404 });
  },
};
