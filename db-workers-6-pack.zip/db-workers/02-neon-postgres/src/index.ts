import { neon } from "@neondatabase/serverless";

export default {
  async fetch(req: Request, env: { NEON_DATABASE_URL: string }) {
    const sql = neon(env.NEON_DATABASE_URL);
    const url = new URL(req.url);

    if (url.pathname === "/health") {
      const rows = await sql`SELECT 1 AS ok`;
      return Response.json({ db: "neon-postgres", ok: rows?.[0]?.ok === 1 });
    }

    if (url.pathname === "/users" && req.method === "GET") {
      const rows = await sql`SELECT id, email, created_at FROM users ORDER BY created_at DESC LIMIT 50`;
      return Response.json({ users: rows });
    }

    if (url.pathname === "/users" && req.method === "POST") {
      const body = await req.json().catch(() => ({} as any));
      const email = String(body.email || "");
      if (!email) return Response.json({ error: "email_required" }, { status: 400 });

      const id = crypto.randomUUID();
      await sql`INSERT INTO users (id, email, created_at) VALUES (${id}, ${email}, NOW())`;
      return Response.json({ ok: true, id });
    }

    return new Response("Not Found", { status: 404 });
  },
};
