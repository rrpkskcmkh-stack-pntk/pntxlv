# 02-neon-postgres

## Env
NEON_DATABASE_URL=postgresql://...

## Install
npm i

## Deploy
wrangler deploy
