import { createClient } from "@libsql/client";

export default {
  async fetch(req: Request, env: { TURSO_DATABASE_URL: string; TURSO_AUTH_TOKEN: string }) {
    const db = createClient({ url: env.TURSO_DATABASE_URL, authToken: env.TURSO_AUTH_TOKEN });
    const url = new URL(req.url);

    if (url.pathname === "/health") {
      const r = await db.execute("SELECT 1 AS ok");
      return Response.json({ db: "turso-libsql", ok: (r.rows?.[0] as any)?.ok === 1 });
    }

    if (url.pathname === "/users" && req.method === "GET") {
      const r = await db.execute("SELECT id, email, created_at FROM users ORDER BY created_at DESC LIMIT 50");
      return Response.json({ users: r.rows ?? [] });
    }

    if (url.pathname === "/users" && req.method === "POST") {
      const body = await req.json().catch(() => ({} as any));
      const email = String(body.email || "");
      if (!email) return Response.json({ error: "email_required" }, { status: 400 });

      const id = crypto.randomUUID();
      await db.execute({
        sql: "INSERT INTO users (id, email, created_at) VALUES (?, ?, datetime('now'))",
        args: [id, email],
      });
      return Response.json({ ok: true, id });
    }

    return new Response("Not Found", { status: 404 });
  },
};
