# 04-turso-libsql

## Env
TURSO_DATABASE_URL=libsql://...
TURSO_AUTH_TOKEN=...

## Install
npm i

## Deploy
wrangler deploy
